﻿namespace _0408_RockPaperScissors
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUserRock = new System.Windows.Forms.Button();
            this.btnUserPaper = new System.Windows.Forms.Button();
            this.btnUserSiccors = new System.Windows.Forms.Button();
            this.lbChoose = new System.Windows.Forms.Label();
            this.lbComputer = new System.Windows.Forms.Label();
            this.txtComputerChoice = new System.Windows.Forms.TextBox();
            this.lbResult = new System.Windows.Forms.Label();
            this.lbUserScore = new System.Windows.Forms.Label();
            this.lbComputerScore = new System.Windows.Forms.Label();
            this.txtUserScore = new System.Windows.Forms.TextBox();
            this.txtComputerScore = new System.Windows.Forms.TextBox();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.lbUserChoice = new System.Windows.Forms.Label();
            this.lbCompChoice = new System.Windows.Forms.Label();
            this.txtDrawScore = new System.Windows.Forms.TextBox();
            this.lbDrawScore = new System.Windows.Forms.Label();
            this.picUser = new System.Windows.Forms.PictureBox();
            this.picComputer = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picComputer)).BeginInit();
            this.SuspendLayout();
            // 
            // btnUserRock
            // 
            this.btnUserRock.BackColor = System.Drawing.SystemColors.Control;
            this.btnUserRock.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnUserRock.Location = new System.Drawing.Point(15, 25);
            this.btnUserRock.Name = "btnUserRock";
            this.btnUserRock.Size = new System.Drawing.Size(75, 23);
            this.btnUserRock.TabIndex = 0;
            this.btnUserRock.Text = "Rock";
            this.btnUserRock.UseVisualStyleBackColor = false;
            this.btnUserRock.Click += new System.EventHandler(this.btnUserRock_Click);
            // 
            // btnUserPaper
            // 
            this.btnUserPaper.BackColor = System.Drawing.SystemColors.Control;
            this.btnUserPaper.Location = new System.Drawing.Point(15, 54);
            this.btnUserPaper.Name = "btnUserPaper";
            this.btnUserPaper.Size = new System.Drawing.Size(75, 23);
            this.btnUserPaper.TabIndex = 1;
            this.btnUserPaper.Text = "Paper";
            this.btnUserPaper.UseVisualStyleBackColor = false;
            this.btnUserPaper.Click += new System.EventHandler(this.btnUserPaper_Click);
            // 
            // btnUserSiccors
            // 
            this.btnUserSiccors.BackColor = System.Drawing.SystemColors.Control;
            this.btnUserSiccors.Location = new System.Drawing.Point(15, 87);
            this.btnUserSiccors.Name = "btnUserSiccors";
            this.btnUserSiccors.Size = new System.Drawing.Size(75, 23);
            this.btnUserSiccors.TabIndex = 2;
            this.btnUserSiccors.Text = "Scissors";
            this.btnUserSiccors.UseVisualStyleBackColor = false;
            this.btnUserSiccors.Click += new System.EventHandler(this.btnUserSiccors_Click);
            // 
            // lbChoose
            // 
            this.lbChoose.AutoSize = true;
            this.lbChoose.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbChoose.Location = new System.Drawing.Point(12, 9);
            this.lbChoose.Name = "lbChoose";
            this.lbChoose.Size = new System.Drawing.Size(53, 13);
            this.lbChoose.TabIndex = 3;
            this.lbChoose.Text = "Choose:";
            // 
            // lbComputer
            // 
            this.lbComputer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbComputer.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbComputer.Location = new System.Drawing.Point(128, 9);
            this.lbComputer.Name = "lbComputer";
            this.lbComputer.Size = new System.Drawing.Size(85, 13);
            this.lbComputer.TabIndex = 4;
            this.lbComputer.Text = "Computer:";
            this.lbComputer.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtComputerChoice
            // 
            this.txtComputerChoice.BackColor = System.Drawing.Color.White;
            this.txtComputerChoice.Enabled = false;
            this.txtComputerChoice.Location = new System.Drawing.Point(123, 37);
            this.txtComputerChoice.Multiline = true;
            this.txtComputerChoice.Name = "txtComputerChoice";
            this.txtComputerChoice.ReadOnly = true;
            this.txtComputerChoice.Size = new System.Drawing.Size(85, 52);
            this.txtComputerChoice.TabIndex = 5;
            this.txtComputerChoice.TabStop = false;
            this.txtComputerChoice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbResult
            // 
            this.lbResult.AutoSize = true;
            this.lbResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResult.Location = new System.Drawing.Point(219, 9);
            this.lbResult.Name = "lbResult";
            this.lbResult.Size = new System.Drawing.Size(72, 25);
            this.lbResult.TabIndex = 6;
            this.lbResult.Text = "Result:";
            // 
            // lbUserScore
            // 
            this.lbUserScore.AutoSize = true;
            this.lbUserScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUserScore.Location = new System.Drawing.Point(221, 98);
            this.lbUserScore.Name = "lbUserScore";
            this.lbUserScore.Size = new System.Drawing.Size(63, 13);
            this.lbUserScore.TabIndex = 7;
            this.lbUserScore.Text = "User Score:";
            // 
            // lbComputerScore
            // 
            this.lbComputerScore.AutoSize = true;
            this.lbComputerScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbComputerScore.Location = new System.Drawing.Point(221, 137);
            this.lbComputerScore.Name = "lbComputerScore";
            this.lbComputerScore.Size = new System.Drawing.Size(86, 13);
            this.lbComputerScore.TabIndex = 8;
            this.lbComputerScore.Text = "Computer Score:";
            // 
            // txtUserScore
            // 
            this.txtUserScore.BackColor = System.Drawing.Color.White;
            this.txtUserScore.Enabled = false;
            this.txtUserScore.Location = new System.Drawing.Point(224, 114);
            this.txtUserScore.Name = "txtUserScore";
            this.txtUserScore.ReadOnly = true;
            this.txtUserScore.Size = new System.Drawing.Size(83, 20);
            this.txtUserScore.TabIndex = 9;
            this.txtUserScore.TabStop = false;
            // 
            // txtComputerScore
            // 
            this.txtComputerScore.BackColor = System.Drawing.Color.White;
            this.txtComputerScore.Enabled = false;
            this.txtComputerScore.Location = new System.Drawing.Point(224, 153);
            this.txtComputerScore.Name = "txtComputerScore";
            this.txtComputerScore.ReadOnly = true;
            this.txtComputerScore.Size = new System.Drawing.Size(83, 20);
            this.txtComputerScore.TabIndex = 10;
            this.txtComputerScore.TabStop = false;
            // 
            // txtResult
            // 
            this.txtResult.BackColor = System.Drawing.Color.White;
            this.txtResult.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtResult.Location = new System.Drawing.Point(224, 37);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.ReadOnly = true;
            this.txtResult.Size = new System.Drawing.Size(83, 38);
            this.txtResult.TabIndex = 11;
            this.txtResult.TabStop = false;
            // 
            // lbUserChoice
            // 
            this.lbUserChoice.Location = new System.Drawing.Point(18, 195);
            this.lbUserChoice.Name = "lbUserChoice";
            this.lbUserChoice.Size = new System.Drawing.Size(87, 27);
            this.lbUserChoice.TabIndex = 12;
            this.lbUserChoice.Text = "You chose scissors";
            // 
            // lbCompChoice
            // 
            this.lbCompChoice.Location = new System.Drawing.Point(121, 195);
            this.lbCompChoice.Name = "lbCompChoice";
            this.lbCompChoice.Size = new System.Drawing.Size(87, 27);
            this.lbCompChoice.TabIndex = 13;
            this.lbCompChoice.Text = "Computer chose scissors";
            // 
            // txtDrawScore
            // 
            this.txtDrawScore.BackColor = System.Drawing.Color.White;
            this.txtDrawScore.Enabled = false;
            this.txtDrawScore.Location = new System.Drawing.Point(224, 192);
            this.txtDrawScore.Name = "txtDrawScore";
            this.txtDrawScore.ReadOnly = true;
            this.txtDrawScore.Size = new System.Drawing.Size(83, 20);
            this.txtDrawScore.TabIndex = 15;
            this.txtDrawScore.TabStop = false;
            // 
            // lbDrawScore
            // 
            this.lbDrawScore.AutoSize = true;
            this.lbDrawScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDrawScore.Location = new System.Drawing.Point(221, 176);
            this.lbDrawScore.Name = "lbDrawScore";
            this.lbDrawScore.Size = new System.Drawing.Size(43, 13);
            this.lbDrawScore.TabIndex = 14;
            this.lbDrawScore.Text = "Draws: ";
            // 
            // picUser
            // 
            this.picUser.Location = new System.Drawing.Point(15, 116);
            this.picUser.Name = "picUser";
            this.picUser.Size = new System.Drawing.Size(90, 76);
            this.picUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picUser.TabIndex = 16;
            this.picUser.TabStop = false;
            // 
            // picComputer
            // 
            this.picComputer.Location = new System.Drawing.Point(123, 116);
            this.picComputer.Name = "picComputer";
            this.picComputer.Size = new System.Drawing.Size(90, 76);
            this.picComputer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picComputer.TabIndex = 17;
            this.picComputer.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(323, 228);
            this.Controls.Add(this.picComputer);
            this.Controls.Add(this.picUser);
            this.Controls.Add(this.txtDrawScore);
            this.Controls.Add(this.lbDrawScore);
            this.Controls.Add(this.lbCompChoice);
            this.Controls.Add(this.lbUserChoice);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.txtComputerScore);
            this.Controls.Add(this.txtUserScore);
            this.Controls.Add(this.lbComputerScore);
            this.Controls.Add(this.lbUserScore);
            this.Controls.Add(this.lbResult);
            this.Controls.Add(this.txtComputerChoice);
            this.Controls.Add(this.lbComputer);
            this.Controls.Add(this.lbChoose);
            this.Controls.Add(this.btnUserSiccors);
            this.Controls.Add(this.btnUserPaper);
            this.Controls.Add(this.btnUserRock);
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.Text = "Rock Paper Scissors";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picComputer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUserRock;
        private System.Windows.Forms.Button btnUserPaper;
        private System.Windows.Forms.Button btnUserSiccors;
        private System.Windows.Forms.Label lbChoose;
        private System.Windows.Forms.Label lbComputer;
        private System.Windows.Forms.TextBox txtComputerChoice;
        private System.Windows.Forms.Label lbResult;
        private System.Windows.Forms.Label lbUserScore;
        private System.Windows.Forms.Label lbComputerScore;
        private System.Windows.Forms.TextBox txtUserScore;
        private System.Windows.Forms.TextBox txtComputerScore;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Label lbUserChoice;
        private System.Windows.Forms.Label lbCompChoice;
        private System.Windows.Forms.TextBox txtDrawScore;
        private System.Windows.Forms.Label lbDrawScore;
        private System.Windows.Forms.PictureBox picUser;
        private System.Windows.Forms.PictureBox picComputer;
    }
}

