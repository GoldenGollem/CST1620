﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0408_RockPaperScissors
{
    public partial class MainForm : Form
    {
        Random randomNum = new Random();

        enum Selection { ROCK, PAPER, SCISSORS };

        Selection userChoice, computerChoice;

        int userScore, computerScore, drawScore;
        int result;//User win = 1, Comp win = 2, draw = 0

        private void btnUserRock_Click(object sender, EventArgs e)
        {
            userChoice = Selection.ROCK;
            ChoiceComparisons(userChoice);
            DisplayOutcome();
        }

        private void btnUserPaper_Click(object sender, EventArgs e)
        {
            userChoice = Selection.PAPER;
            ChoiceComparisons(userChoice);
            DisplayOutcome();
        }

        private void btnUserSiccors_Click(object sender, EventArgs e)
        {
            userChoice = Selection.SCISSORS;
            ChoiceComparisons(userChoice);
            DisplayOutcome();
        }

        public MainForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            userScore = 0;
            lbUserChoice.Text = "";
            computerScore = 0;
            lbCompChoice.Text = "";
            drawScore = 0;
        }

        private void ChoiceComparisons(Selection user)
        {
            result = 0;
            computerChoice = (Selection)randomNum.Next(3);
            UpdatePicture(user, computerChoice);
            lbUserChoice.Text = "You chose " + Convert.ToString((Selection)user);
            lbCompChoice.Text = "Computer chose " + Convert.ToString((Selection)computerChoice);
            if (user != computerChoice)
            {
                switch (user)
                {
                    case Selection.PAPER:
                        if (computerChoice == Selection.ROCK)
                        {
                            result = 1;
                        }
                        else if (computerChoice == Selection.SCISSORS)
                        {
                            result = 2;
                        }
                        break;
                    case Selection.ROCK:
                        if (computerChoice == Selection.SCISSORS)
                        {
                            result = 1;
                        }
                        else if (computerChoice == Selection.PAPER)
                        {
                            result = 2;
                        }
                        break;
                    case Selection.SCISSORS:
                        if (computerChoice == Selection.PAPER)
                        {
                            result = 1;
                        }
                        else if (computerChoice == Selection.ROCK)
                        {
                            result = 2;
                        }
                        break;
                }
            }
            if (result == 1)
            {
                userScore++;
            }
            else if (result == 2)
            {
                computerScore++;
            }
            else if (result == 0)
            {
                drawScore++;
            }
        }
        private void DisplayOutcome()
        {
            //Update computer choice
            txtComputerChoice.Text = Convert.ToString((Selection)computerChoice);
            //Update Results
            if (result == 1)
            {
                txtResult.Text = "User Wins!";
                txtResult.ForeColor = Color.Lime;
            }
            else if (result == 2)
            {
                txtResult.Text = "Computer Wins";
                txtResult.ForeColor = Color.Red;
            }
            else
            {
                txtResult.Text = "Draw";
                txtResult.ForeColor = Color.MidnightBlue;
            }
            txtUserScore.Text = Convert.ToString(userScore);
            txtComputerScore.Text = Convert.ToString(computerScore);
            txtDrawScore.Text = Convert.ToString(drawScore);
        }
        private void UpdatePicture(Selection user, Selection comp)
        {
            if (user == Selection.PAPER)
                picUser.Image = global::_0408_RockPaperScissors.Properties.Resources.paper;
            if (user == Selection.ROCK)
                picUser.Image = global::_0408_RockPaperScissors.Properties.Resources.rock;
            if (user == Selection.SCISSORS)
                picUser.Image = global::_0408_RockPaperScissors.Properties.Resources.scissors;
            if (comp == Selection.PAPER)
                picComputer.Image = global::_0408_RockPaperScissors.Properties.Resources.paper;
            if (comp == Selection.ROCK)
                picComputer.Image = global::_0408_RockPaperScissors.Properties.Resources.rock;
            if (comp == Selection.SCISSORS)
                picComputer.Image = global::_0408_RockPaperScissors.Properties.Resources.scissors;

        }

    }
}
