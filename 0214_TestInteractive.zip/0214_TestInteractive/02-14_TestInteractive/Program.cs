﻿//Author: Nate Christensen
//Date: 08/28/2018
//Test Interactive
//Prompts user for 8 test scores
//and displays the average to the 
//hundreths decimal place
using System;

namespace TestInteractive
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            int score1, score2, score3, score4, 
                score5, score6, score7, score8;
            double total=0.0;
            double average;
            Console.WriteLine("Please enter test score #1");
            score1 = Convert.ToInt32(Console.ReadLine());
            total = total + score1;
            Console.WriteLine("Please enter test score #2");
            score2 = Convert.ToInt32(Console.ReadLine());
            total = total + score2;
            Console.WriteLine("Please enter test score #3");
            score3 = Convert.ToInt32(Console.ReadLine());
            total = total + score3;
            Console.WriteLine("Please enter test score #4");
            score4 = Convert.ToInt32(Console.ReadLine());
            total = total + score4;
            Console.WriteLine("Please enter test score #5");
            score5 = Convert.ToInt32(Console.ReadLine());
            total = total + score5;
            Console.WriteLine("Please enter test score #6");
            score6 = Convert.ToInt32(Console.ReadLine());
            total = total + score6;
            Console.WriteLine("Please enter test score #7");
            score7 = Convert.ToInt32(Console.ReadLine());
            total = total + score7;
            Console.WriteLine("Please enter test score #8");
            score8 = Convert.ToInt32(Console.ReadLine());
            total = total + score8;
            average = total / 8.0;
            Console.WriteLine("Average Score: " + average);
        }
    }
}
