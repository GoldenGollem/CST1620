﻿//Author : Nate Christensen
//Date : 08/29/2018
//PersonalInfo
//Displays a person's, birthdate, cell phone number and work phone number

using System;

namespace _PersonalInfo
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("NAME : John Smith");
            Console.WriteLine("Birthdate : 01/23/1945");
            Console.WriteLine("Work Phone : (855)676-2448");
            Console.WriteLine("Cell Phone : (612)848-2284");
            Console.WriteLine("Press any key to close");
            Console.ReadKey();
        }
    }
}
