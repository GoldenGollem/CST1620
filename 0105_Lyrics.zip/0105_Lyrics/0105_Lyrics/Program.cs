﻿//Program.cs
//Author : Nate Christensne
//Date : 08/29/2018
//Displays at least 4 lines of lyrics from a song

using System;

namespace _Lyrics
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            string Title = "Monophobia";
            string Artist = "deadmau5 & Rob Swire";
            Console.WriteLine(Title + " By: " + Artist);
            Console.WriteLine("Inside my head, there's a little place left for you");
            Console.WriteLine("What do you know?");
            Console.WriteLine("What do you know?");
            Console.WriteLine("And all I want is to find out what you're going through");
            Console.WriteLine("What do I know?");
            Console.WriteLine("Maybe this silence is dangerous");
            Console.ReadKey();
        }
    }
}
