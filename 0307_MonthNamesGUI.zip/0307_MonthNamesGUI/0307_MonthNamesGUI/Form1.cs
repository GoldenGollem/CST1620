﻿//Month Names GUI
//Author : Nate Christensen
//Date : 09/14/2018

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0307_MonthNamesGUI
{
    public partial class FormMain : Form
    {
        private enum months
        {
            January=1, Febuary, March, April,
            May, June, July, August,
            September, October, November, December
        }
        public FormMain()
        {
            InitializeComponent();
        }

        private void btLookup_Click(object sender, EventArgs e)
        {
            int monthNum;
            string monthName;
            monthNum = Convert.ToInt16(txtNumber.Text);
            monthName = Convert.ToString((months)monthNum);
            txtMonth.Text = monthName;
        }
    }
}
