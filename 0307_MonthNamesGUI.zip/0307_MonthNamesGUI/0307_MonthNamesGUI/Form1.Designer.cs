﻿namespace _0307_MonthNamesGUI
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbDescription = new System.Windows.Forms.Label();
            this.lbNumbers = new System.Windows.Forms.Label();
            this.txtNumber = new System.Windows.Forms.TextBox();
            this.lbMonth = new System.Windows.Forms.Label();
            this.txtMonth = new System.Windows.Forms.TextBox();
            this.btLookup = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbDescription
            // 
            this.lbDescription.Location = new System.Drawing.Point(12, 9);
            this.lbDescription.Name = "lbDescription";
            this.lbDescription.Size = new System.Drawing.Size(135, 34);
            this.lbDescription.TabIndex = 0;
            this.lbDescription.Text = "Enter a number to lookup the corrisponding Month";
            // 
            // lbNumbers
            // 
            this.lbNumbers.AutoSize = true;
            this.lbNumbers.Location = new System.Drawing.Point(12, 52);
            this.lbNumbers.Name = "lbNumbers";
            this.lbNumbers.Size = new System.Drawing.Size(28, 13);
            this.lbNumbers.TabIndex = 1;
            this.lbNumbers.Text = "1-12";
            // 
            // txtNumber
            // 
            this.txtNumber.BackColor = System.Drawing.Color.SeaShell;
            this.txtNumber.Location = new System.Drawing.Point(46, 49);
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(101, 20);
            this.txtNumber.TabIndex = 2;
            // 
            // lbMonth
            // 
            this.lbMonth.AutoSize = true;
            this.lbMonth.Location = new System.Drawing.Point(12, 109);
            this.lbMonth.Name = "lbMonth";
            this.lbMonth.Size = new System.Drawing.Size(40, 13);
            this.lbMonth.TabIndex = 3;
            this.lbMonth.Text = "Month:";
            this.lbMonth.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtMonth
            // 
            this.txtMonth.BackColor = System.Drawing.Color.SeaShell;
            this.txtMonth.Location = new System.Drawing.Point(58, 106);
            this.txtMonth.Name = "txtMonth";
            this.txtMonth.ReadOnly = true;
            this.txtMonth.Size = new System.Drawing.Size(89, 20);
            this.txtMonth.TabIndex = 4;
            this.txtMonth.TabStop = false;
            // 
            // btLookup
            // 
            this.btLookup.Location = new System.Drawing.Point(12, 75);
            this.btLookup.Name = "btLookup";
            this.btLookup.Size = new System.Drawing.Size(135, 25);
            this.btLookup.TabIndex = 5;
            this.btLookup.Text = "Lookup";
            this.btLookup.UseVisualStyleBackColor = true;
            this.btLookup.Click += new System.EventHandler(this.btLookup_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(149, 136);
            this.Controls.Add(this.btLookup);
            this.Controls.Add(this.txtMonth);
            this.Controls.Add(this.lbMonth);
            this.Controls.Add(this.txtNumber);
            this.Controls.Add(this.lbNumbers);
            this.Controls.Add(this.lbDescription);
            this.Name = "FormMain";
            this.Text = "Month Names GUI";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbDescription;
        private System.Windows.Forms.Label lbNumbers;
        private System.Windows.Forms.TextBox txtNumber;
        private System.Windows.Forms.Label lbMonth;
        private System.Windows.Forms.TextBox txtMonth;
        private System.Windows.Forms.Button btLookup;
    }
}

