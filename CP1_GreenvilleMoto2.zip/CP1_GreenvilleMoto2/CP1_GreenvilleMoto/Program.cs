﻿//Program.cs
//Author : Nate Christensen
//Date : 08/29/2018
//Displays the Greenville moto

using System;

namespace GreenvilleMoto2
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("* * * * * * * *  * * * * * * * * *");
            Console.WriteLine("* The stars shines in Greenville *");
            Console.WriteLine("* * * * * * * *  * * * * * * * * *");
        }
    }
}
