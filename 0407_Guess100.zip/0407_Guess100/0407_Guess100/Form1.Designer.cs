﻿namespace _0407_Guess100
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbInstructions = new System.Windows.Forms.Label();
            this.lbTries = new System.Windows.Forms.Label();
            this.txtTries = new System.Windows.Forms.TextBox();
            this.txtGuess = new System.Windows.Forms.TextBox();
            this.lbGuess = new System.Windows.Forms.Label();
            this.btCheck = new System.Windows.Forms.Button();
            this.lbGuessInd = new System.Windows.Forms.Label();
            this.btReset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbInstructions
            // 
            this.lbInstructions.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbInstructions.Location = new System.Drawing.Point(13, 13);
            this.lbInstructions.Name = "lbInstructions";
            this.lbInstructions.Size = new System.Drawing.Size(156, 42);
            this.lbInstructions.TabIndex = 0;
            this.lbInstructions.Text = "Guess a Number between 1 and 100";
            this.lbInstructions.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbTries
            // 
            this.lbTries.AutoSize = true;
            this.lbTries.Location = new System.Drawing.Point(16, 141);
            this.lbTries.Name = "lbTries";
            this.lbTries.Size = new System.Drawing.Size(36, 13);
            this.lbTries.TabIndex = 1;
            this.lbTries.Text = "Tries: ";
            // 
            // txtTries
            // 
            this.txtTries.BackColor = System.Drawing.SystemColors.Control;
            this.txtTries.Location = new System.Drawing.Point(58, 138);
            this.txtTries.Name = "txtTries";
            this.txtTries.Size = new System.Drawing.Size(48, 20);
            this.txtTries.TabIndex = 2;
            this.txtTries.TabStop = false;
            // 
            // txtGuess
            // 
            this.txtGuess.Location = new System.Drawing.Point(77, 58);
            this.txtGuess.Name = "txtGuess";
            this.txtGuess.Size = new System.Drawing.Size(70, 20);
            this.txtGuess.TabIndex = 4;
            this.txtGuess.Click += new System.EventHandler(this.txtGuess_Click);
            // 
            // lbGuess
            // 
            this.lbGuess.AutoSize = true;
            this.lbGuess.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGuess.Location = new System.Drawing.Point(31, 61);
            this.lbGuess.Name = "lbGuess";
            this.lbGuess.Size = new System.Drawing.Size(40, 13);
            this.lbGuess.TabIndex = 3;
            this.lbGuess.Text = "Guess:";
            // 
            // btCheck
            // 
            this.btCheck.Location = new System.Drawing.Point(17, 84);
            this.btCheck.Name = "btCheck";
            this.btCheck.Size = new System.Drawing.Size(152, 23);
            this.btCheck.TabIndex = 5;
            this.btCheck.Text = "Check";
            this.btCheck.UseVisualStyleBackColor = true;
            this.btCheck.Click += new System.EventHandler(this.btCheck_Click);
            // 
            // lbGuessInd
            // 
            this.lbGuessInd.ForeColor = System.Drawing.Color.Lime;
            this.lbGuessInd.Location = new System.Drawing.Point(14, 110);
            this.lbGuessInd.Name = "lbGuessInd";
            this.lbGuessInd.Size = new System.Drawing.Size(155, 15);
            this.lbGuessInd.TabIndex = 6;
            this.lbGuessInd.Text = "Your guess was _";
            this.lbGuessInd.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbGuessInd.Visible = false;
            // 
            // btReset
            // 
            this.btReset.Enabled = false;
            this.btReset.Location = new System.Drawing.Point(112, 135);
            this.btReset.Name = "btReset";
            this.btReset.Size = new System.Drawing.Size(59, 25);
            this.btReset.TabIndex = 7;
            this.btReset.TabStop = false;
            this.btReset.Text = "Reset";
            this.btReset.UseVisualStyleBackColor = true;
            this.btReset.Visible = false;
            this.btReset.Click += new System.EventHandler(this.btReset_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(181, 170);
            this.Controls.Add(this.btReset);
            this.Controls.Add(this.lbGuessInd);
            this.Controls.Add(this.btCheck);
            this.Controls.Add(this.txtGuess);
            this.Controls.Add(this.lbGuess);
            this.Controls.Add(this.txtTries);
            this.Controls.Add(this.lbTries);
            this.Controls.Add(this.lbInstructions);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormMain";
            this.Text = "Guessing Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbInstructions;
        private System.Windows.Forms.Label lbTries;
        private System.Windows.Forms.TextBox txtTries;
        private System.Windows.Forms.TextBox txtGuess;
        private System.Windows.Forms.Label lbGuess;
        private System.Windows.Forms.Button btCheck;
        private System.Windows.Forms.Label lbGuessInd;
        private System.Windows.Forms.Button btReset;
    }
}

