﻿//Guessing Game
//Author : Nate Christensen
//Date : 09/20/2018

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0407_Guess100
{
    public partial class FormMain : Form
    {

        Random randomNum = new Random();
        int guess, answer, tries;

        private void btReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        public FormMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            answer = randomNum.Next(1, 101);
        }
        

        private void txtGuess_Click(object sender, EventArgs e)
        {

            txtGuess.Text = "";
        }

        private void btCheck_Click(object sender, EventArgs e)
        {
            guess = Convert.ToInt16(txtGuess.Text);
            if(guess == answer)
            {
                lbGuessInd.Visible = true;
                lbGuessInd.Text = "You guessed Correctly!";
                lbGuessInd.ForeColor = Color.Lime;
                btReset.Enabled = true;
                btReset.TabStop = true;
                btReset.Visible = true;
            }
            else if (guess < answer)
            {
                lbGuessInd.Visible = true;
                lbGuessInd.Text = $"You guess of {guess} is LOW";
                lbGuessInd.ForeColor = Color.Blue;
            }
            else if (guess > answer)
            {
                lbGuessInd.Visible = true;
                lbGuessInd.Text = $"You guess of {guess} is HIGH";
                lbGuessInd.ForeColor = Color.Red;
            }
            tries++;
            txtTries.Text = Convert.ToString(tries);
        }

        public void ResetForm()
        {
            lbGuessInd.Visible = false;
            btReset.Enabled = false;
            btReset.TabStop = false;
            btReset.Visible = false;
            txtGuess.Text = "";
            txtTries.Text = "";
            guess = 0;
            tries = 0;
            answer = randomNum.Next(1, 101);
        }
        
    }
}
