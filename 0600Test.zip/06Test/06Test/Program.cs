﻿using System;
using System.Linq;

namespace _06Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            int salary;
            double weight;
            const int MAXSALARYLENGTH = 15;
            //double[] sales;
            //sales = new double[20];
            double[] sales = { 89.5, 23.4, 90.3, 45.6, 89.9, 12.7, 77.8 };
            // Console.WriteLine($"Value of sales[6] = {sales[6]}");
            // Console.WriteLine($"Value of sales[3] = {sales[3]}");

            for (int i=0;i<sales.Length;i++)
            {
                Console.WriteLine($"Value of sales[{i}] = {sales[i]}");
            }

            Console.WriteLine("================================================");

            foreach (double values in sales)
            {
                Console.WriteLine($"Value of sales[] = {values}");
            }

            Console.WriteLine("================================================");

            foreach (double values in sales)
            {
                Console.WriteLine($"Value of sales[] = {values}");
                if (values != 0) break;
            }

            Console.WriteLine("============ Average of the Array ============");
            double average = sales.Average();
            Console.WriteLine($"Average Value of sales[] = {average}");

            Console.WriteLine("============= Sorting the Array ==============");
            Array.Sort(sales);
            for (int i = 0; i < sales.Length; i++)
            {
                Console.WriteLine($"Value of sales[{i}] = {sales[i]}");
            }

            Console.WriteLine("========= Reverse Sorting the Array =========");
            Array.Sort(sales);
            Array.Reverse(sales);
            for (int i = 0; i < sales.Length; i++)
            {
                Console.WriteLine($"Value of sales[{i}] = {sales[i]}");
            }

            Console.WriteLine("========= Where is 45.6 in the Array =========");
            Console.WriteLine(Array.IndexOf(sales, 45.6));

            Console.WriteLine("================================================");


            Console.WriteLine("Press any key to quit");
            Console.ReadKey();
        }
    }
}
