﻿//Program.cs
//Author : Nate Christensne
//Date : 08/29/2018
//displays a statement that defines comments

using System;

namespace _Comments
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("comments are nonexecuting statements that you add to document a program");
        }
        /* End of Main */
    }
}
 