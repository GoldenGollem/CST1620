﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0513CountVowels
{
    public partial class FormMain : Form
    {
        int vowelCount = 0;
        int charCount = 0;

        public FormMain()
        {
            InitializeComponent();
        }

        private void txtParagraph_TextChanged(object sender, EventArgs e)
        {
            countVowels(txtParagraph.Text);
        }

        private void btCount_Click(object sender, EventArgs e)
        {
            countVowels(txtParagraph.Text);
        }
        private void countVowels(string text)
        {
            vowelCount = 0;
            string input = text.ToLower();
            charCount = input.Length;
            for(int i=0;i<charCount; i++)
            {
                char letter = input[i];
                if (letter == 'a') vowelCount++;
                if (letter == 'e') vowelCount++;
                if (letter == 'i') vowelCount++;
                if (letter == 'o') vowelCount++;
                if (letter == 'u') vowelCount++;

                //== ("a" || "e" || "i" || "o" || "u")

            }
            txtVowels.Text = $"{vowelCount}";
        }
    }
}
