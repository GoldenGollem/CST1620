﻿namespace _0513CountVowels
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbDirections = new System.Windows.Forms.Label();
            this.txtParagraph = new System.Windows.Forms.TextBox();
            this.btCount = new System.Windows.Forms.Button();
            this.lbVowels = new System.Windows.Forms.Label();
            this.txtVowels = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbDirections
            // 
            this.lbDirections.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDirections.Location = new System.Drawing.Point(13, 13);
            this.lbDirections.Name = "lbDirections";
            this.lbDirections.Size = new System.Drawing.Size(257, 33);
            this.lbDirections.TabIndex = 0;
            this.lbDirections.Text = "Enter a paragraph of text. All vowels will be counted. \"Y\" is not considered a vo" +
    "wel for this application.";
            this.lbDirections.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtParagraph
            // 
            this.txtParagraph.Location = new System.Drawing.Point(13, 49);
            this.txtParagraph.Multiline = true;
            this.txtParagraph.Name = "txtParagraph";
            this.txtParagraph.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtParagraph.Size = new System.Drawing.Size(257, 115);
            this.txtParagraph.TabIndex = 1;
            this.txtParagraph.TextChanged += new System.EventHandler(this.txtParagraph_TextChanged);
            // 
            // btCount
            // 
            this.btCount.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btCount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btCount.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btCount.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btCount.Location = new System.Drawing.Point(16, 171);
            this.btCount.Name = "btCount";
            this.btCount.Size = new System.Drawing.Size(98, 37);
            this.btCount.TabIndex = 2;
            this.btCount.Text = "Count";
            this.btCount.UseVisualStyleBackColor = false;
            this.btCount.Click += new System.EventHandler(this.btCount_Click);
            // 
            // lbVowels
            // 
            this.lbVowels.AutoSize = true;
            this.lbVowels.Location = new System.Drawing.Point(188, 183);
            this.lbVowels.Name = "lbVowels";
            this.lbVowels.Size = new System.Drawing.Size(40, 13);
            this.lbVowels.TabIndex = 3;
            this.lbVowels.Text = "vowels";
            // 
            // txtVowels
            // 
            this.txtVowels.BackColor = System.Drawing.SystemColors.Control;
            this.txtVowels.Enabled = false;
            this.txtVowels.Location = new System.Drawing.Point(120, 180);
            this.txtVowels.Name = "txtVowels";
            this.txtVowels.Size = new System.Drawing.Size(62, 20);
            this.txtVowels.TabIndex = 4;
            this.txtVowels.TabStop = false;
            this.txtVowels.Text = "0";
            this.txtVowels.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(291, 220);
            this.Controls.Add(this.txtVowels);
            this.Controls.Add(this.lbVowels);
            this.Controls.Add(this.btCount);
            this.Controls.Add(this.txtParagraph);
            this.Controls.Add(this.lbDirections);
            this.Name = "FormMain";
            this.Text = "05-09 Count Vowels";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbDirections;
        private System.Windows.Forms.TextBox txtParagraph;
        private System.Windows.Forms.Button btCount;
        private System.Windows.Forms.Label lbVowels;
        private System.Windows.Forms.TextBox txtVowels;
    }
}

