﻿using System;

namespace RWC_W1_ConsoleApp1
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Press Any Key to End");
            Console.ReadKey();
        }
    }
}
