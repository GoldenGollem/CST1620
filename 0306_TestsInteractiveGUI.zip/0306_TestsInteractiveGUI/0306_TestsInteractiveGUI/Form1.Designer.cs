﻿namespace _0306_TestsInteractiveGUI
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbScore1 = new System.Windows.Forms.Label();
            this.txtScore1 = new System.Windows.Forms.TextBox();
            this.txtScore2 = new System.Windows.Forms.TextBox();
            this.lbScore2 = new System.Windows.Forms.Label();
            this.txtScore3 = new System.Windows.Forms.TextBox();
            this.lbScore3 = new System.Windows.Forms.Label();
            this.txtAvgScore = new System.Windows.Forms.TextBox();
            this.lbAvgScore = new System.Windows.Forms.Label();
            this.txtScore5 = new System.Windows.Forms.TextBox();
            this.lbScore5 = new System.Windows.Forms.Label();
            this.txtScore4 = new System.Windows.Forms.TextBox();
            this.lbScore4 = new System.Windows.Forms.Label();
            this.btCalculate = new System.Windows.Forms.Button();
            this.lbDescription = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbScore1
            // 
            this.lbScore1.AutoSize = true;
            this.lbScore1.Location = new System.Drawing.Point(12, 38);
            this.lbScore1.Name = "lbScore1";
            this.lbScore1.Size = new System.Drawing.Size(47, 13);
            this.lbScore1.TabIndex = 0;
            this.lbScore1.Text = "Score 1:";
            this.lbScore1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtScore1
            // 
            this.txtScore1.Location = new System.Drawing.Point(68, 38);
            this.txtScore1.Name = "txtScore1";
            this.txtScore1.Size = new System.Drawing.Size(155, 20);
            this.txtScore1.TabIndex = 1;
            // 
            // txtScore2
            // 
            this.txtScore2.Location = new System.Drawing.Point(68, 67);
            this.txtScore2.Name = "txtScore2";
            this.txtScore2.Size = new System.Drawing.Size(155, 20);
            this.txtScore2.TabIndex = 3;
            // 
            // lbScore2
            // 
            this.lbScore2.AutoSize = true;
            this.lbScore2.Location = new System.Drawing.Point(12, 67);
            this.lbScore2.Name = "lbScore2";
            this.lbScore2.Size = new System.Drawing.Size(47, 13);
            this.lbScore2.TabIndex = 2;
            this.lbScore2.Text = "Score 2:";
            // 
            // txtScore3
            // 
            this.txtScore3.Location = new System.Drawing.Point(68, 93);
            this.txtScore3.Name = "txtScore3";
            this.txtScore3.Size = new System.Drawing.Size(155, 20);
            this.txtScore3.TabIndex = 5;
            // 
            // lbScore3
            // 
            this.lbScore3.AutoSize = true;
            this.lbScore3.Location = new System.Drawing.Point(12, 93);
            this.lbScore3.Name = "lbScore3";
            this.lbScore3.Size = new System.Drawing.Size(47, 13);
            this.lbScore3.TabIndex = 4;
            this.lbScore3.Text = "Score 3:";
            // 
            // txtAvgScore
            // 
            this.txtAvgScore.Location = new System.Drawing.Point(99, 220);
            this.txtAvgScore.Name = "txtAvgScore";
            this.txtAvgScore.ReadOnly = true;
            this.txtAvgScore.Size = new System.Drawing.Size(124, 20);
            this.txtAvgScore.TabIndex = 11;
            // 
            // lbAvgScore
            // 
            this.lbAvgScore.AutoSize = true;
            this.lbAvgScore.Location = new System.Drawing.Point(12, 220);
            this.lbAvgScore.Name = "lbAvgScore";
            this.lbAvgScore.Size = new System.Drawing.Size(81, 13);
            this.lbAvgScore.TabIndex = 10;
            this.lbAvgScore.Text = "Average Score:";
            // 
            // txtScore5
            // 
            this.txtScore5.Location = new System.Drawing.Point(68, 148);
            this.txtScore5.Name = "txtScore5";
            this.txtScore5.Size = new System.Drawing.Size(155, 20);
            this.txtScore5.TabIndex = 9;
            // 
            // lbScore5
            // 
            this.lbScore5.AutoSize = true;
            this.lbScore5.Location = new System.Drawing.Point(12, 148);
            this.lbScore5.Name = "lbScore5";
            this.lbScore5.Size = new System.Drawing.Size(47, 13);
            this.lbScore5.TabIndex = 8;
            this.lbScore5.Text = "Score 5:";
            // 
            // txtScore4
            // 
            this.txtScore4.Location = new System.Drawing.Point(68, 119);
            this.txtScore4.Name = "txtScore4";
            this.txtScore4.Size = new System.Drawing.Size(155, 20);
            this.txtScore4.TabIndex = 7;
            // 
            // lbScore4
            // 
            this.lbScore4.AutoSize = true;
            this.lbScore4.Location = new System.Drawing.Point(12, 119);
            this.lbScore4.Name = "lbScore4";
            this.lbScore4.Size = new System.Drawing.Size(47, 13);
            this.lbScore4.TabIndex = 6;
            this.lbScore4.Text = "Score 4:";
            // 
            // btCalculate
            // 
            this.btCalculate.BackColor = System.Drawing.Color.DodgerBlue;
            this.btCalculate.Location = new System.Drawing.Point(12, 174);
            this.btCalculate.Name = "btCalculate";
            this.btCalculate.Size = new System.Drawing.Size(211, 40);
            this.btCalculate.TabIndex = 12;
            this.btCalculate.TabStop = false;
            this.btCalculate.Text = "Calculate";
            this.btCalculate.UseVisualStyleBackColor = false;
            this.btCalculate.Click += new System.EventHandler(this.btCalculate_Click);
            // 
            // lbDescription
            // 
            this.lbDescription.Font = new System.Drawing.Font("Algerian", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDescription.Location = new System.Drawing.Point(12, 9);
            this.lbDescription.Name = "lbDescription";
            this.lbDescription.Size = new System.Drawing.Size(211, 24);
            this.lbDescription.TabIndex = 13;
            this.lbDescription.Text = "Enter 5 Numbers to calculate the average of those numbers";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(233, 253);
            this.Controls.Add(this.lbDescription);
            this.Controls.Add(this.btCalculate);
            this.Controls.Add(this.txtAvgScore);
            this.Controls.Add(this.lbAvgScore);
            this.Controls.Add(this.txtScore5);
            this.Controls.Add(this.lbScore5);
            this.Controls.Add(this.txtScore4);
            this.Controls.Add(this.lbScore4);
            this.Controls.Add(this.txtScore3);
            this.Controls.Add(this.lbScore3);
            this.Controls.Add(this.txtScore2);
            this.Controls.Add(this.lbScore2);
            this.Controls.Add(this.txtScore1);
            this.Controls.Add(this.lbScore1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormMain";
            this.Text = "Tests Interactive GUI";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbScore1;
        private System.Windows.Forms.TextBox txtScore1;
        private System.Windows.Forms.TextBox txtScore2;
        private System.Windows.Forms.Label lbScore2;
        private System.Windows.Forms.TextBox txtScore3;
        private System.Windows.Forms.Label lbScore3;
        private System.Windows.Forms.TextBox txtAvgScore;
        private System.Windows.Forms.Label lbAvgScore;
        private System.Windows.Forms.TextBox txtScore5;
        private System.Windows.Forms.Label lbScore5;
        private System.Windows.Forms.TextBox txtScore4;
        private System.Windows.Forms.Label lbScore4;
        private System.Windows.Forms.Button btCalculate;
        private System.Windows.Forms.Label lbDescription;
    }
}

