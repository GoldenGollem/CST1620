﻿//TestInteractiveGUI
//Author : Nate Christensen
//Date : 09/14/2018

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0306_TestsInteractiveGUI
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btCalculate_Click(object sender, EventArgs ex)
        {
            decimal a, b, c, d, e;
            decimal average;
            a = Convert.ToDecimal(txtScore1.Text);
            b = Convert.ToDecimal(txtScore2.Text);
            c = Convert.ToDecimal(txtScore3.Text);
            d = Convert.ToDecimal(txtScore4.Text);
            e = Convert.ToDecimal(txtScore5.Text);
            average = a + b + c + d + e;
            average /= 5;
            txtAvgScore.Text = Convert.ToString(average);

        }
    }
}
