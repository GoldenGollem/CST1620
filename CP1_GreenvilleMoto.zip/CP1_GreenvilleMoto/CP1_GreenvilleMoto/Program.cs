﻿//Program.cs
//Author : Nate Christensen
//Date : 08/29/2018
//Displays the Greenville moto

using System;

namespace GreenvilleMoto
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("The stars shines in Greenville");
        }
    }
}
