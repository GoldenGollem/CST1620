﻿//Program.cs
//Author : Nate Christensen
//Date : 08/29/2018
//Displays the Marshalls moto

using System;

namespace MarshallsMoto
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Make your vision your view");
        }
    }
}
