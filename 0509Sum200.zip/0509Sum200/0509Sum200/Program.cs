﻿//Sum200
//Author : Nate Christensen
//Date : 09/26/2018
//Program.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0509Sum200
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Sum the integers from 1 though 200");
            int sum = 0;
            for (int i=1; i <= 200; i++)
            {
                sum = sum + i;
                if (i == 100) Console.WriteLine($"The sum of the first {i} numbers is {sum}");
            }
            Console.WriteLine("Sum of all integers is " + sum);
            Console.WriteLine("Press any key to quit.");
            Console.ReadKey();
        }
    }
}
