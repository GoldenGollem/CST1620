﻿//Author: Nate Christensen
//Date: 08/28/2018
//
using System;

namespace StopSign
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("    XXXXXX");
            Console.WriteLine("  X        X");
            Console.WriteLine("X    STOP    X");
            Console.WriteLine("  X        X");
            Console.WriteLine("    XXXXXX");
            Console.WriteLine("       X");
            Console.WriteLine("       X");
            Console.WriteLine("       X");
            Console.ReadKey();
        }
    }
}
