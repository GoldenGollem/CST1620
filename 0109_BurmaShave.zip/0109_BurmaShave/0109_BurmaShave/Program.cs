﻿//Program.cs
//Author : Nate Christensen
//Date : 08/29/2018
//Displays a classic Burma Shave rhyme

using System;

namespace BurmaShave
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Little Willie");
            Console.WriteLine("Modern soul");
            Console.WriteLine("Busted Papa's");
            Console.WriteLine("Brush and bowl");
            Console.WriteLine("Nice work Willie");
            Console.WriteLine("Burma-Shave");
            Console.ReadKey();
        }
    }
}
