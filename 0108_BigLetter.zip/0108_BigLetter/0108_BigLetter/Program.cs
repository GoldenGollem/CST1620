﻿//Program.cs
//Author : Nate Christensne
//Date : 08/29/2018
//outputs a letter composed of smaller letters

using System;

namespace _BigLetter
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("TTTTTTTTTTT");
            Console.WriteLine("     T");
            Console.WriteLine("     T");
            Console.WriteLine("     T");
            Console.WriteLine("     T");
            Console.WriteLine("     T");
            Console.WriteLine("     T");
            Console.ReadKey();
        }
    }
}
